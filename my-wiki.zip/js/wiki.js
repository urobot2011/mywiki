var headingArray = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
headingArray.forEach((el) => {
    var headings = [];
    headingArray.slice(0, headingArray.indexOf(el)+1).forEach(element => {
        headings.push('main '+element);
    });
    $('main '+el).each((index, $$el) => {
        var $el = $($$el);
        $el.prepend('<i class="bi bi-chevron-down wiki-i wiki-collapse"></i>');
        $el.find('.wiki-collapse').click(() => {
            $el.toggleClass('wiki-disabled');
            $el.find('.wiki-collapse').toggleClass('bi-chevron-down');
            $el.find('.wiki-collapse').toggleClass('bi-chevron-right');
            var isdisabled = $el.hasClass('wiki-disabled');
            $el.nextUntil($(headings.join(', '))).each((i, e) => {
                if(isdisabled){
                    $(e).hide(250);
                    $(e).find('.wiki-collapse').removeClass('bi-chevron-down');
                    $(e).find('.wiki-collapse').addClass('bi-chevron-right');
                    $(e).addClass('wiki-disabled');
                } else { 
                    $(e).show(250);
                    $(e).find('.wiki-collapse').addClass('bi-chevron-down');
                    $(e).find('.wiki-collapse').removeClass('bi-chevron-right');
                    $(e).removeClass('wiki-disabled');
                }
            });
        });
    });
});