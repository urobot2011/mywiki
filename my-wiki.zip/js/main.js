window.onbeforeunload = function(e){
    if(e != null && e != undefined){
        $('#progressBar').css('width', '100%');
    }
};
$(window).on('load', function(){
    $('#progressBar').css('width', '0%');
});